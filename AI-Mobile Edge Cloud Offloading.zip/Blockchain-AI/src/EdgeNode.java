
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EdgeNode {
    private String configFilePath;

    public EdgeNode(String configFilePath) {
        this.configFilePath = configFilePath;
        loadConfiguration();
    }

    private void loadConfiguration() {
        // Read edge node configuration from file
        try (BufferedReader br = new BufferedReader(new FileReader(configFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("Config: " + line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String readData(String dataFilePath) {
        StringBuilder data = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                data.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data.toString();
    }
}
