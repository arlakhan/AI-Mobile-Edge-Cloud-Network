public class Main {
    public static void main(String[] args) {
        Blockchain blockchain = new Blockchain();
        EdgeNode edgeNode = new EdgeNode("edge.txt");

        String dataToProcess = edgeNode.readData("data.txt");
        
        String processedData = AIProcessor.processData(dataToProcess);

        Block newBlock = new Block(processedData);
        blockchain.addBlock(newBlock);

        blockchain.displayBlockchain();
    }
}
