import java.util.ArrayList;
import java.util.List;

public class Blockchain {
    private List<Block> chain;

    public Blockchain() {
        chain = new ArrayList<>();
        chain.add(createGenesisBlock());
    }

    private Block createGenesisBlock() {
        return new Block("Genesis Block");
    }

    public void addBlock(Block newBlock) {
        newBlock.setPreviousHash(chain.get(chain.size() - 1).getHash());
        newBlock.mineBlock(4);
        chain.add(newBlock);
    }

    public void displayBlockchain() {
        for (Block block : chain) {
            System.out.println(block);
        }
    }
}
